<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* presentation.html.twig */
class __TwigTemplate_27f7e3dec426e1d789b7fd1d23a91baa6f227f90ce1a61a633ea6fbb972aa4a3 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "presentation.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "presentation.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "presentation.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <b>Le secteur d'activité</b>
        <p>L’industrie pharmaceutique est un secteur très lucratif dans lequel le mouvement de fusion acquisition
        est très fort. Les regroupements de laboratoires ces dernières années ont donné naissance à des
        entités gigantesques au sein desquelles le travail est longtemps resté organisé selon les anciennes
        structures.<br>
        Des déboires divers récents autour de médicaments ou molécules ayant entraîné des complications
        médicales ont fait s'élever des voix contre une partie de l'activité des laboratoires : la visite médicale,
        réputée être le lieu d' arrangements entre l'industrie et les praticiens, et tout du moins un terrain
        d'influence opaque.</p>
    <b>L'entreprise</b>
        <p>Le laboratoire Galaxy Swiss Bourdin (GSB) est issu de la fusion entre le géant américain Galaxy
        (spécialisé dans le secteur des maladies virales dont le SIDA et les hépatites) et le conglomérat
        européen Swiss Bourdin (travaillant sur des médicaments plus conventionnels), lui même déjà union
        de trois petits laboratoires .<br>
        En 2009, les deux géants pharmaceutiques ont uni leurs forces pour créer un leader de ce secteur
        industriel. L'entité Galaxy Swiss Bourdin Europe a établi son siège administratif à Paris.<br>
        Le siège social de la multinationale est situé à Philadelphie, Pennsylvanie, aux Etats-Unis.<p>
        <div style=\"text-align:center\">
            <b><i>La France a été choisie comme témoin pour l'amélioration du suivi de l'activité de visite.</i></b>
        </div>
        <br>
    <b>Réorganisation</b>
        <p>Une conséquence de cette fusion, est la recherche d'une optimisation de l’activité du groupe ainsi
        constitué en réalisant des économies d’échelle dans la production et la distribution des médicaments
        (en passant par une nécessaire restructuration et vague de licenciement), tout en prenant le meilleur
        des deux laboratoires sur les produits concurrents.<br>
        L'entreprise compte 480 visiteurs médicaux en France métropolitaine (Corse comprise), et 60 dans les
        départements et territoires d'outre-mer. Les territoires sont répartis en 6 secteurs géographiques
        (Paris-Centre, Sud, Nord, Ouest, Est, DTOM Caraïbes-Amériques, DTOM Asie-Afrique).<br>
        Une vision partielle de cette organisation est présentée ci-dessous.</p><br>
        <img class=\"centrer\" src=\"images/france.png\"><br>
       
        
        
    <b>Les visiteurs</b>
    <p>La force commerciale d'un laboratoire pharmaceutique est assurée par un travail 
    de conseil et d'information auprès des prescripteurs. Les visiteurs médicaux 
    (ou délégués) démarchent les médecins, pharmaciens, infirmières et 
    autres métiers de santé susceptibles de prescrire aux patients les produits du 
    laboratoire.</p>
    <p>L'objectif d'une visite est d'actualiser et rafraîchir la connaissance des 
    professionnels de santé sur les produits de l'entreprise. Les visiteurs ne font 
    pas de vente, mais leurs interventions ont un impact certain sur la prescription 
    de la pharmacopée du laboratoire.</p>
    <p>Pour donner une organisation commune aux délégués médicaux, l'entreprise a adopté 
    l'organisation de la flotte de visiteurs existant chez Galaxy, selon un système 
    hiérarchique par région et, à un niveau supérieur, par secteur géographique
    (Sud, Nord, Paris-Centre, Antilles-Guyane, etc).</p>
    <p>Il n'y a pas eu d'harmonisation de la relation entre les personnels de terrain 
    (Visiteurs et Délégués régionaux) et les responsables de secteur. 
    Les habitudes en cours avant la fusion ont été adaptées sans que soient données 
    des directives au niveau local.</p>
     <img class=\"centrer\" src=\"images/hierarchie.png\">
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "presentation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}
{% block body %}
    <b>Le secteur d'activité</b>
        <p>L’industrie pharmaceutique est un secteur très lucratif dans lequel le mouvement de fusion acquisition
        est très fort. Les regroupements de laboratoires ces dernières années ont donné naissance à des
        entités gigantesques au sein desquelles le travail est longtemps resté organisé selon les anciennes
        structures.<br>
        Des déboires divers récents autour de médicaments ou molécules ayant entraîné des complications
        médicales ont fait s'élever des voix contre une partie de l'activité des laboratoires : la visite médicale,
        réputée être le lieu d' arrangements entre l'industrie et les praticiens, et tout du moins un terrain
        d'influence opaque.</p>
    <b>L'entreprise</b>
        <p>Le laboratoire Galaxy Swiss Bourdin (GSB) est issu de la fusion entre le géant américain Galaxy
        (spécialisé dans le secteur des maladies virales dont le SIDA et les hépatites) et le conglomérat
        européen Swiss Bourdin (travaillant sur des médicaments plus conventionnels), lui même déjà union
        de trois petits laboratoires .<br>
        En 2009, les deux géants pharmaceutiques ont uni leurs forces pour créer un leader de ce secteur
        industriel. L'entité Galaxy Swiss Bourdin Europe a établi son siège administratif à Paris.<br>
        Le siège social de la multinationale est situé à Philadelphie, Pennsylvanie, aux Etats-Unis.<p>
        <div style=\"text-align:center\">
            <b><i>La France a été choisie comme témoin pour l'amélioration du suivi de l'activité de visite.</i></b>
        </div>
        <br>
    <b>Réorganisation</b>
        <p>Une conséquence de cette fusion, est la recherche d'une optimisation de l’activité du groupe ainsi
        constitué en réalisant des économies d’échelle dans la production et la distribution des médicaments
        (en passant par une nécessaire restructuration et vague de licenciement), tout en prenant le meilleur
        des deux laboratoires sur les produits concurrents.<br>
        L'entreprise compte 480 visiteurs médicaux en France métropolitaine (Corse comprise), et 60 dans les
        départements et territoires d'outre-mer. Les territoires sont répartis en 6 secteurs géographiques
        (Paris-Centre, Sud, Nord, Ouest, Est, DTOM Caraïbes-Amériques, DTOM Asie-Afrique).<br>
        Une vision partielle de cette organisation est présentée ci-dessous.</p><br>
        <img class=\"centrer\" src=\"images/france.png\"><br>
       
        
        
    <b>Les visiteurs</b>
    <p>La force commerciale d'un laboratoire pharmaceutique est assurée par un travail 
    de conseil et d'information auprès des prescripteurs. Les visiteurs médicaux 
    (ou délégués) démarchent les médecins, pharmaciens, infirmières et 
    autres métiers de santé susceptibles de prescrire aux patients les produits du 
    laboratoire.</p>
    <p>L'objectif d'une visite est d'actualiser et rafraîchir la connaissance des 
    professionnels de santé sur les produits de l'entreprise. Les visiteurs ne font 
    pas de vente, mais leurs interventions ont un impact certain sur la prescription 
    de la pharmacopée du laboratoire.</p>
    <p>Pour donner une organisation commune aux délégués médicaux, l'entreprise a adopté 
    l'organisation de la flotte de visiteurs existant chez Galaxy, selon un système 
    hiérarchique par région et, à un niveau supérieur, par secteur géographique
    (Sud, Nord, Paris-Centre, Antilles-Guyane, etc).</p>
    <p>Il n'y a pas eu d'harmonisation de la relation entre les personnels de terrain 
    (Visiteurs et Délégués régionaux) et les responsables de secteur. 
    Les habitudes en cours avant la fusion ont été adaptées sans que soient données 
    des directives au niveau local.</p>
     <img class=\"centrer\" src=\"images/hierarchie.png\">
{% endblock %}", "presentation.html.twig", "G:\\uniserverz\\www\\sf4_Gsb\\templates\\presentation.html.twig");
    }
}
