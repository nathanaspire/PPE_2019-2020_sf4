<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_91916e334c9e2ebf2192c6814fde86c4e730b26ba702b9787a257a68f098a661 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'header' => [$this, 'block_header'],
            'menu' => [$this, 'block_menu'],
            'button' => [$this, 'block_button'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "    </head>
            ";
        // line 11
        $this->displayBlock('header', $context, $blocks);
        // line 20
        echo "        
    <body>
     <div class=\"container\">
        <div class=\"row\">
                ";
        // line 24
        $this->displayBlock('menu', $context, $blocks);
        // line 47
        echo "        ";
        $this->displayBlock('button', $context, $blocks);
        // line 48
        echo "         <div class=\"contenu paragraphe col-lg-8\">
            ";
        // line 49
        $this->displayBlock('body', $context, $blocks);
        // line 80
        echo "          </div>
        </div>
     </div>
        
    ";
        // line 84
        $this->displayBlock('javascripts', $context, $blocks);
        // line 85
        echo "        </body>
        
        
    ";
        // line 88
        $this->displayBlock('footer', $context, $blocks);
        // line 144
        echo "
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "GSB Labs";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bootstrap.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("GSB_CSS.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 11
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header"));

        // line 12
        echo "            <nav class=\"navbar navbar-expand-sm bg-light navbar-light header\">
                    <img class=\"taillelogo\" src=\"images/logo-gsb.png\">
              <div class=\"collapse navbar-collapse\" id=\"collapsibleNavbar\">
                <ul class=\"navbar-nav\">   
                </ul>
              </div>  
            </nav>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 24
    public function block_menu($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "menu"));

        // line 25
        echo "                    <nav class=\"navbar navbar-expand-sm bg-light navbar-light menu\">
                          <div class=\"collapse navbar-collapse\" id=\"collapsibleNavbar\">
                            <ul class=\"navbar-nav\">
                                <li class=\"nav-item\">
                                  <a class=\"navbar-brand menucolor\" href=\"";
        // line 29
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">Accueil</a>
                                </li>
                                <li class=\"nav-item\">
                                  <a class=\"nav-link menucolor\" href=\"";
        // line 32
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("presentation");
        echo "\">Qui sommes-nous?</a>
                                </li>

                                <li class=\"nav-item\">
                                  <a class=\"nav-link menucolor\" href=\"";
        // line 36
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("si");
        echo "\">
                                    Notre SI
                                  </a>
                                </li>
                                <li class=\"nav-item\">
                                  <a class=\"nav-link menucolor\" href=\"";
        // line 41
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("users");
        echo "\">Les utilisateurs</a>
                                </li>
                            </ul>
                          </div>  
                    </nav>
                ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 47
    public function block_button($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 49
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 50
        echo "                <h2>Bienvenue sur le site des laboratoires Galaxy Swiss Bourdin</h2><br>
                <h5>Des visiteurs médicaux à votre écoute et proposant le meilleur de
                    l'industrie pharmaceutique.</h5><br><br>

                <h4>Nos collaborateurs et clients s'expriment:</h4><br>
                <ul class=\"nav nav-pills flex-column comments\">
                    <li>
                        <img class=\"clientimg\" src=\"images/gerard.jpg\">
                        <b><h6>Gérard D., Médecin au CHR de Lille</h6></b>
                        <p><i>\"Depuis que je travaille avec GSB, je recommande
                        leurs produits à mes patients\"</i></p>
                    </li>
                    <li>
                        <img class=\"clientimg\" src=\"images/emilie.jpg\">
                        <b><h6>Emilie A., Visiteur chez GSB</h6></b>
                        <p><i>\"C'est un plaisir de travailler avec GSB. Nous sommes 
                                bien accueillis par les médecins et l'entreprise
                                prend soin de ses visiteurs\"</i></p>
                    </li>
                    <li>
                        <img class=\"clientimg\" src=\"images/clement.jpg\">
                        <b><h6>Clément C., Pharmacien dans la banlieue Parisienne</h6></b>
                        <p><i>\"Cette entreprise tient à faire les choses 
                                correctement, et cela se ressent !\"</i></p>
                    </li>
                </ul>



            ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 84
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 88
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 89
        echo "        <div><!-- Footer -->
        <footer class=\"page-footer font-small blue pt-4\">

          <!-- Footer Links -->
          <div class=\"container-fluid text-center text-md-left\">

            <!-- Grid row -->
            <div class=\"row footer\">

              <!-- Grid column -->
              <div class=\"col-md-6 mt-md-0 mt-3\">

                <!-- Content -->
                <h5 class=\"text-uppercase\">nous contacter</h5>
                        adresse: 12 rue Georges Pompidou - 75000 PARIS<br>
                        tel: 06-12-34-56-78<br>
                        mail: contact@gsb.com

              </div>
              <!-- Grid column -->

              <hr class=\"clearfix w-100 d-md-none pb-3\">

              <!-- Grid column -->
              <div class=\"col-md-3 mb-md-0 mb-3\">

                <!-- Links -->
                <h5 class=\"text-uppercase\">Aller vers...</h5>

                <ul class=\"list-unstyled\">
                  <li>
                    <a href=\"";
        // line 120
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">Accueil</a>
                  </li>
                  <li>
                    <a href=\"";
        // line 123
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("presentation");
        echo "\">Qui sommes-nous?</a>
                  </li>
                  <li>
                    <a href=\"";
        // line 126
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("si");
        echo "\">Notre Système Informatique</a>
                  </li>
                </ul>

              </div>

          </div>
          <!-- Footer Links -->

        </footer>
        <!-- Footer -->
        
        <!-- Copyright -->
          <div class=\"text-center py-3 copyright\">
              © 2018 Copyright: Sophia LALOUX
          </div>
        <!-- Copyright -->
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  377 => 126,  371 => 123,  365 => 120,  332 => 89,  322 => 88,  304 => 84,  265 => 50,  255 => 49,  237 => 47,  221 => 41,  213 => 36,  206 => 32,  200 => 29,  194 => 25,  184 => 24,  167 => 12,  157 => 11,  145 => 8,  140 => 7,  130 => 6,  111 => 5,  99 => 144,  97 => 88,  92 => 85,  90 => 84,  84 => 80,  82 => 49,  79 => 48,  76 => 47,  74 => 24,  68 => 20,  66 => 11,  63 => 10,  61 => 6,  57 => 5,  51 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>{% block title %}GSB Labs{% endblock %}</title>
        {% block stylesheets %}
            <link rel=\"stylesheet\" href=\"{{asset(\"bootstrap.css\")}}\">
            <link rel=\"stylesheet\" href=\"{{asset(\"GSB_CSS.css\")}}\">
        {% endblock %}
    </head>
            {% block header %}
            <nav class=\"navbar navbar-expand-sm bg-light navbar-light header\">
                    <img class=\"taillelogo\" src=\"images/logo-gsb.png\">
              <div class=\"collapse navbar-collapse\" id=\"collapsibleNavbar\">
                <ul class=\"navbar-nav\">   
                </ul>
              </div>  
            </nav>
        {% endblock %}
        
    <body>
     <div class=\"container\">
        <div class=\"row\">
                {% block menu %}
                    <nav class=\"navbar navbar-expand-sm bg-light navbar-light menu\">
                          <div class=\"collapse navbar-collapse\" id=\"collapsibleNavbar\">
                            <ul class=\"navbar-nav\">
                                <li class=\"nav-item\">
                                  <a class=\"navbar-brand menucolor\" href=\"{{path('accueil')}}\">Accueil</a>
                                </li>
                                <li class=\"nav-item\">
                                  <a class=\"nav-link menucolor\" href=\"{{path('presentation')}}\">Qui sommes-nous?</a>
                                </li>

                                <li class=\"nav-item\">
                                  <a class=\"nav-link menucolor\" href=\"{{path('si')}}\">
                                    Notre SI
                                  </a>
                                </li>
                                <li class=\"nav-item\">
                                  <a class=\"nav-link menucolor\" href=\"{{path('users')}}\">Les utilisateurs</a>
                                </li>
                            </ul>
                          </div>  
                    </nav>
                {% endblock %}
        {% block button %}{% endblock %}
         <div class=\"contenu paragraphe col-lg-8\">
            {% block body %}
                <h2>Bienvenue sur le site des laboratoires Galaxy Swiss Bourdin</h2><br>
                <h5>Des visiteurs médicaux à votre écoute et proposant le meilleur de
                    l'industrie pharmaceutique.</h5><br><br>

                <h4>Nos collaborateurs et clients s'expriment:</h4><br>
                <ul class=\"nav nav-pills flex-column comments\">
                    <li>
                        <img class=\"clientimg\" src=\"images/gerard.jpg\">
                        <b><h6>Gérard D., Médecin au CHR de Lille</h6></b>
                        <p><i>\"Depuis que je travaille avec GSB, je recommande
                        leurs produits à mes patients\"</i></p>
                    </li>
                    <li>
                        <img class=\"clientimg\" src=\"images/emilie.jpg\">
                        <b><h6>Emilie A., Visiteur chez GSB</h6></b>
                        <p><i>\"C'est un plaisir de travailler avec GSB. Nous sommes 
                                bien accueillis par les médecins et l'entreprise
                                prend soin de ses visiteurs\"</i></p>
                    </li>
                    <li>
                        <img class=\"clientimg\" src=\"images/clement.jpg\">
                        <b><h6>Clément C., Pharmacien dans la banlieue Parisienne</h6></b>
                        <p><i>\"Cette entreprise tient à faire les choses 
                                correctement, et cela se ressent !\"</i></p>
                    </li>
                </ul>



            {% endblock %}
          </div>
        </div>
     </div>
        
    {% block javascripts %}{% endblock %}
        </body>
        
        
    {% block footer %}
        <div><!-- Footer -->
        <footer class=\"page-footer font-small blue pt-4\">

          <!-- Footer Links -->
          <div class=\"container-fluid text-center text-md-left\">

            <!-- Grid row -->
            <div class=\"row footer\">

              <!-- Grid column -->
              <div class=\"col-md-6 mt-md-0 mt-3\">

                <!-- Content -->
                <h5 class=\"text-uppercase\">nous contacter</h5>
                        adresse: 12 rue Georges Pompidou - 75000 PARIS<br>
                        tel: 06-12-34-56-78<br>
                        mail: contact@gsb.com

              </div>
              <!-- Grid column -->

              <hr class=\"clearfix w-100 d-md-none pb-3\">

              <!-- Grid column -->
              <div class=\"col-md-3 mb-md-0 mb-3\">

                <!-- Links -->
                <h5 class=\"text-uppercase\">Aller vers...</h5>

                <ul class=\"list-unstyled\">
                  <li>
                    <a href=\"{{ path('accueil') }}\">Accueil</a>
                  </li>
                  <li>
                    <a href=\"{{ path('presentation') }}\">Qui sommes-nous?</a>
                  </li>
                  <li>
                    <a href=\"{{ path('si') }}\">Notre Système Informatique</a>
                  </li>
                </ul>

              </div>

          </div>
          <!-- Footer Links -->

        </footer>
        <!-- Footer -->
        
        <!-- Copyright -->
          <div class=\"text-center py-3 copyright\">
              © 2018 Copyright: Sophia LALOUX
          </div>
        <!-- Copyright -->
    {% endblock %}

</html>
", "base.html.twig", "G:\\uniserverz\\www\\sf4_Gsb\\templates\\base.html.twig");
    }
}
