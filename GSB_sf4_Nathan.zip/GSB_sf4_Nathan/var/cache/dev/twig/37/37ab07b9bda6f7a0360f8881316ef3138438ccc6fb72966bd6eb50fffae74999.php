<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Notre_SI.html.twig */
class __TwigTemplate_1d4650b0cf0aa4f1dfdc698c6c41a0817b383e10d11166959534e60f22a49ad3 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'button' => [$this, 'block_button'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Notre_SI.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Notre_SI.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "Notre_SI.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_button($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "button"));

        // line 4
        echo "    <div class=\"boutonsires\">
        <button type=\"button\" class=\"btn btn-info btn-lg\" disabled>le SI</button>
        <a href=\"";
        // line 6
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("reseau");
        echo "\" class=\"btn btn-info btn-lg boutonecart\">Le Réseau</a>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    <div class=\"test\">
        <h2><b>Le système informatique des laboratoires GSB</b></h2><br>
        <div class=\"paragraphe\">
            <p>Sur le site parisien, toutes les fonctions administratives (gestion des ressources humaines,
            comptabilité, direction, commerciale, etc.) sont présentes. On trouve en outre un service laborecherche, le service juridique et le service communication.<br>
            La salle serveur occupe le 6ème étage du bâtiment et les accès y sont restreints (étage accessible par
            ascenseur à l'aide d'une clé sécurisée, portes d'accès par escalier munies d'un lecteur de badge, sas
            d'entrée avec gardien présent 24h/24).<br>
            Les serveurs assurent les fonctions de base du réseau (DHCP, DNS, Annuaire et gestion centralisée
            des environnements) et les fonctions de communication (Intranet, Messagerie, Agenda partagé, etc.).
            On trouve aussi de nombreuses applications métier (base d'information pharmaceutique, serveurs
            dédiés à la recherche, base de données des produits du laboratoire, base de données des licences
            d'exploitation pharmaceutique, etc.) et les fonctions plus génériques de toute entreprise (Progiciel de
            Gestion Intégré avec ses modules RH, GRC, etc.).
            Un nombre croissant de serveurs est virtualisé.<br>
            Constitué autour de VLAN, le réseau segmente les services de manière à fluidifier le trafic.<br>
            Les données de l'entreprises sont considérées comme stratégiques et ne peuvent tolérer ni fuite, ni
            destruction. L'ensemble des informations est répliqué quotidiennement aux Etats-Unis par un lien
            dédié. Toutes les fonctions de redondances (RAID, alimentation, lien réseau redondant, Spanningtree, clustering, etc.) sont mises en œuvre pour assurer une tolérance aux pannes maximale.</p>
    
            <br><br>
            <h3><b>La gestion informatique</b></h3><br>
            <p>La DSI (Direction des Services Informatiques) est une entité importante de la structure Europe qui
                participe aux choix stratégiques.<br>
            Pour Swiss-Bourdin, qui occupait le siège parisien avant la fusion, l'outil informatique et l'utilisation
            d'outils décisionnels pour améliorer la vision et la planification de l'activité ont toujours fait partie de la
            politique maison, en particulier pour ce qui concerne la partie recherche, production, communication et
            juridique.</p>
            
            <i>La partie commerciale a été le parent pauvre de cette informatisation, les visiteurs étant vus
            comme des acteurs distants autonomes. La DSI a convaincu l'entreprise que l'intégration des
            données fournies par cette partie aura un impact important sur l'ensemble de l'activité.</i>
        </div>
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "Notre_SI.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 11,  86 => 10,  73 => 6,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}

{% block button %}
    <div class=\"boutonsires\">
        <button type=\"button\" class=\"btn btn-info btn-lg\" disabled>le SI</button>
        <a href=\"{{ path('reseau') }}\" class=\"btn btn-info btn-lg boutonecart\">Le Réseau</a>
    </div>
{% endblock %}

{% block body %}
    <div class=\"test\">
        <h2><b>Le système informatique des laboratoires GSB</b></h2><br>
        <div class=\"paragraphe\">
            <p>Sur le site parisien, toutes les fonctions administratives (gestion des ressources humaines,
            comptabilité, direction, commerciale, etc.) sont présentes. On trouve en outre un service laborecherche, le service juridique et le service communication.<br>
            La salle serveur occupe le 6ème étage du bâtiment et les accès y sont restreints (étage accessible par
            ascenseur à l'aide d'une clé sécurisée, portes d'accès par escalier munies d'un lecteur de badge, sas
            d'entrée avec gardien présent 24h/24).<br>
            Les serveurs assurent les fonctions de base du réseau (DHCP, DNS, Annuaire et gestion centralisée
            des environnements) et les fonctions de communication (Intranet, Messagerie, Agenda partagé, etc.).
            On trouve aussi de nombreuses applications métier (base d'information pharmaceutique, serveurs
            dédiés à la recherche, base de données des produits du laboratoire, base de données des licences
            d'exploitation pharmaceutique, etc.) et les fonctions plus génériques de toute entreprise (Progiciel de
            Gestion Intégré avec ses modules RH, GRC, etc.).
            Un nombre croissant de serveurs est virtualisé.<br>
            Constitué autour de VLAN, le réseau segmente les services de manière à fluidifier le trafic.<br>
            Les données de l'entreprises sont considérées comme stratégiques et ne peuvent tolérer ni fuite, ni
            destruction. L'ensemble des informations est répliqué quotidiennement aux Etats-Unis par un lien
            dédié. Toutes les fonctions de redondances (RAID, alimentation, lien réseau redondant, Spanningtree, clustering, etc.) sont mises en œuvre pour assurer une tolérance aux pannes maximale.</p>
    
            <br><br>
            <h3><b>La gestion informatique</b></h3><br>
            <p>La DSI (Direction des Services Informatiques) est une entité importante de la structure Europe qui
                participe aux choix stratégiques.<br>
            Pour Swiss-Bourdin, qui occupait le siège parisien avant la fusion, l'outil informatique et l'utilisation
            d'outils décisionnels pour améliorer la vision et la planification de l'activité ont toujours fait partie de la
            politique maison, en particulier pour ce qui concerne la partie recherche, production, communication et
            juridique.</p>
            
            <i>La partie commerciale a été le parent pauvre de cette informatisation, les visiteurs étant vus
            comme des acteurs distants autonomes. La DSI a convaincu l'entreprise que l'intégration des
            données fournies par cette partie aura un impact important sur l'ensemble de l'activité.</i>
        </div>
    </div>

{% endblock %}", "Notre_SI.html.twig", "D:\\uniserverz\\www\\sf4_Gsb\\templates\\Notre_SI.html.twig");
    }
}
