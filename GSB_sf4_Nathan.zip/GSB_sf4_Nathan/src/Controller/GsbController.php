<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class GsbController extends AbstractController
{
    /**
    * @Route("/accueil", name="accueil")
    */
    
  // route pour aller sur index  
    public function accueil()
    {
        return $this->render('base.html.twig', [
            'controller_name' => 'Controller'
        ]);
    }
    
    /**
    * @Route("/notre_si", name="si")
    */
    //page systeme informatique
    public function pagesi()
    {
        return $this->render('Notre_SI.html.twig', [
            'controller_name' => 'Controller'
        ]);
    }
    /**
    * @Route("/qui_sommes_nous", name="presentation")
    */
    //presentation de l'entreprise
    public function presenter()
    {
        return $this->render('presentation.html.twig', [
            'controller_name' => 'Controller'
        ]);
    }
    
    /**
    * @Route("/le_reseau", name="reseau")
    */
     // presentation du réseau de GSB
    public function pagereseau()
    {
        return $this->render('reseau.html.twig', [
            'controller_name' => 'Controller'
        ]);
    }
    /**
    * @Route("/les_utilisateurs", name="users")
    */
    //liste users
    public function Lister()
    {
        $repoU = $this->getDoctrine()->getRepository(\App\Entity\User::class);
        $lesUsers = $repoU->findAll();
        return $this->render('users.html.twig' ,['listeUsers' => $lesUsers]);
    }
    
    /**
    * @Route("/un_utilisateur", name="unUser")
    */
    //user d51
    public function Userd51()
    {
        $repo = $this->getDoctrine()->getRepository(\App\Entity\User::class);
        $unUser = $repo->findUser("a131");
        return $this->render('unUser.html.twig' ,['LeUser' => $unUser]);
    }
    
    /**
    * @Route("/Les_Louis", name="lesLouis")
    */
    //user d51
    public function userLouis()
    {
        $repo = $this->getDoctrine()->getRepository(\App\Entity\User::class);
        $louis = $repo->findByNom("Louis");
        return $this->render('Louis.html.twig' ,['userLouis' => $louis]);
    }
}

