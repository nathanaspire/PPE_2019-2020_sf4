<?php

namespace App\DataFixtures;

use App\Entity\Statut;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class StatusFixtures extends Fixture 
{
    public const STAT1 = 'Visiteur' ;
    public const STAT2 = 'Comptable' ;
    
    public function load(ObjectManager $manager)
    {
        // creation Status Visiteur
        $unStatut1 = new Statut();
        $unStatut1->setLibelle("Visiteur");
        $manager->persist($unStatut1);
        
        $unStatut2 = new Statut();
        $unStatut2->setLibelle("Comptable");
        $manager->persist($unStatut2);
        
        $manager->flush();
        
        $this->addReference(self :: STAT1, $unStatut1 );
        $this->addReference(self :: STAT2, $unStatut2 );
    }
}
