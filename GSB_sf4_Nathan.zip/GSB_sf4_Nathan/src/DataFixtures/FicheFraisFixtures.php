<?php

/*namespace App\DataFixtures;

use App\Entity\FicheFrais;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use App\DataFixtures\UserFixtures;
use App\DataFixtures\EtatFixtures;

class FicheFraisFixtures extends Fixture implements DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        // creation de la fiche 1 de Terry
        $uneFiche = new FicheFrais();
     
        $uneFiche->setDateModif('201909');
        $uneFiche->setNbJustif('2');
        $uneFiche->setIdEtat($this -> getReference(EtatFixtures::ENR));
        $uneFiche->setIdUser($this -> getReference(UserFixtures::USER1));
        $manager->persist($uneFiche);
        // creation de la fiche 2 de Terry
        $uneFiche2 = new FicheFrais();
        $uneFiche2->setDateModif('201910');
        $uneFiche2->setNbJustif('1');
        $uneFiche2->setIdEtat($this -> getReference(EtatFixtures::ENR));
        $uneFiche2->setIdUser($this -> getReference(UserFixtures::USER1));
        $manager->persist($uneFiche2);
        
        $manager->flush();

    }
    public function getDependencies()
    {
        return [
        UserFixtures :: class ,
        EtatFixtures :: class
       ];
    }
}*/
