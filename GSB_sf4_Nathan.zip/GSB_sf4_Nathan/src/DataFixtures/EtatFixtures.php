<?php

namespace App\DataFixtures;

use App\Entity\Etat;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class EtatFixtures extends Fixture
{
    public const ENR = 'EN' ;
    public const SAI = 'SA' ;

    public function load(ObjectManager $manager)
    {
        // creation de l'état Saisie
        $unEtat1 = new Etat();
        $unEtat1->setLibelle('Saisie');
        $manager->persist($unEtat1);
        
        // creation de l'état Enregistre
        $unEtat2 = new Etat();
        $unEtat2->setLibelle('Enregistre');
        $manager->persist($unEtat2);
        
        $manager->flush();

        $this -> addReference ( self :: ENR , $unEtat2 );
        $this -> addReference ( self :: SAI , $unEtat1 );
    }
}


