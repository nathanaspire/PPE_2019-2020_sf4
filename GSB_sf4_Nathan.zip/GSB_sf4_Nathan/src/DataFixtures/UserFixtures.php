<?php

namespace App\DataFixtures;

use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use DateTime;

class UserFixtures extends Fixture 
{
    public const USER1 = 'TD' ;
    public const USER2 = 'DA' ;
    public const USER3 = 'BC' ;
    
    public function load(ObjectManager $manager)
    {
        // creation Louis Villachane
        $unUser1 = new User();
        $unUser1->setId('a131');
        $unUser1->setNom('Villachane');
        $unUser1->setPrenom('Louis');
        $unUser1->setLogin('lvillachane');
        $unUser1->setMdp('jux7g');
        $unUser1->setAdresse('8 rue des Charmes');
        $unUser1->setCodePostal('46000');
        $unUser1->setVille('Cahors');
        $dateEmb1 = new DateTime("2005-12-21");
        $unUser1->setDateEmbauche($dateEmb1);
        $unUser1->setStatut($this -> getReference(StatusFixtures::STAT1));
        $manager->persist($unUser1);
        
        // creation David Andre
        $unUser2 = new User();
        $unUser2->setId('a17');
        $unUser2->setNom('Andre');
        $unUser2->setPrenom('David');
        $unUser2->setLogin('dandre');
        $unUser2->setMdp('oppg5');
        $unUser2->setAdresse('1 rue Petit');
        $unUser2->setCodePostal('46200');
        $unUser2->setVille('Lalbenque');
        $dateEmb2 = new DateTime("1998-11-23");
        $unUser2->setDateEmbauche($dateEmb2);
        $unUser2->setStatut($this -> getReference(StatusFixtures::STAT2));
        $manager->persist($unUser2);
        
        // creation Christian Bedos
        $unUser3 = new User();
        $unUser3->setId('a55');
        $unUser3->setNom('Bedos');
        $unUser3->setPrenom('Christian');
        $unUser3->setLogin('cbedos');
        $unUser3->setMdp('gmhxz');
        $unUser3->setAdresse('1 rue Peranud');
        $unUser3->setCodePostal('46250');
        $unUser3->setVille('Montcuq');
        $dateEmb3 = new DateTime("1995-01-12");
        $unUser3->setDateEmbauche($dateEmb3);
        $unUser3->setStatut($this -> getReference(StatusFixtures::STAT2));
        $manager->persist($unUser3);
        
        $manager->flush();
        
        $this->addReference(self :: USER1, $unUser1 );
        $this->addReference(self :: USER2, $unUser2 );
        $this->addReference(self :: USER3, $unUser3 );
    }
}

